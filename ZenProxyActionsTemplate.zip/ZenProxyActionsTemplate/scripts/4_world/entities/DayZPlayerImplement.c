modded class DayZPlayerImplement
{
	const static ref array<int> ZENPROXY_GENERIC_SEARCH_IDS = { 9, 10, 25 };

	//! Very janky way of overriding continuous action sound category, but I blame Bohemia for making a stupidly convoluted sound table hashing system
	//! It's definitely not my fault for being dumb as fuck.
	override void OnSoundEvent(string pEventType, string pUserString, int pUserInt)
	{
		// Override pUserInt id of 41 (mine bush) with a different sound if hash matches my custom sound categories
		if (pUserInt == 41)
		{
			if (m_ActionSoundCategoryHash == 1400970649) // zenproxysearch
				pUserInt = ZENPROXY_GENERIC_SEARCH_IDS.GetRandomElement();
			else if (m_ActionSoundCategoryHash == -158240139) // zenproxysearchpaper
				pUserInt = Math.RandomIntInclusive(9, 12);
			else if (m_ActionSoundCategoryHash == -154508100) // zenproxysearchradio
				pUserInt = 25;
		}

		// For debugging
		//if (m_ActionSoundCategoryHash != 0)
		//	ZenFunctions.DebugMessage("OnSoundEvent pEventType=" + pEventType + " pUserString=" + pUserString + " pUserInt=" + pUserInt + "m_ActionSoundCategoryHash=" + m_ActionSoundCategoryHash);

		super.OnSoundEvent(pEventType, pUserString, pUserInt);
	}
}
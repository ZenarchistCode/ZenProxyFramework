modded class PipeWrench
{
	override void SetActions()
	{
		super.SetActions();

		AddAction(ActionZenRepairSink);
	}
}
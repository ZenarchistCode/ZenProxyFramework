modded class Wrench
{
	override void SetActions()
	{
		super.SetActions();

		AddAction(ActionZenRepairSink);
	}
}
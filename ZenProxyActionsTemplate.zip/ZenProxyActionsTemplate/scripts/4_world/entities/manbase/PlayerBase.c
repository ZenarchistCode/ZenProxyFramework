modded class PlayerBase
{
	protected bool m_ZenSleepingInBed = false;

	override void SetActions(out TInputActionMap InputActionMap)
	{
		super.SetActions(InputActionMap);

		AddAction(ActionZenSleepBed, InputActionMap);
		AddAction(ActionZenDrinkSink, InputActionMap);
		AddAction(ActionZenWashHandsSink, InputActionMap);
		AddAction(ActionZenSearchProxy, InputActionMap);
	}
	
	void SetZenSleepingInBed(bool b)
	{
		m_ZenSleepingInBed = true;
	}

	bool IsZenSleepingInBed()
	{
		return m_ZenSleepingInBed;
	}
}
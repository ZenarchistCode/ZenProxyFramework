/*class Zen_ProxyObject extends BuildingSuper
{
	override bool IsBuilding()
	{
		return false;
	}
};

class Zen_ProxyObject_Debug extends Zen_ProxyObject {};

class Zen_ProxyObject_SodaMachine extends Zen_ProxyObject 
{
	override void SetActions()
	{
		super.SetActions();

		//AddAction(ActionOpenStaticZenMap);
	}
};
*/
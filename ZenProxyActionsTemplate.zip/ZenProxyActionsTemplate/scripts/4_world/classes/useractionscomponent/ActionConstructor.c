modded class ActionConstructor
{
	override void RegisterActions(TTypenameArray actions)
	{
		super.RegisterActions(actions);

		actions.Insert(ActionZenSleepBed);
		actions.Insert(ActionZenRepairSink);
		actions.Insert(ActionZenDrinkSink);
		actions.Insert(ActionZenFillBottleBaseSink);
		actions.Insert(ActionZenWashHandsSink);
		actions.Insert(ActionZenSearchProxy);
	}
}
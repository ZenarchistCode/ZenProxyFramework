class ActionZenSearchProxyCB : ActionContinuousBaseCB
{
	override void CreateActionComponent()
	{
		m_ActionData.m_ActionComponent = new CAContinuousTime(5);
	}
}

class ActionZenSearchProxy : ActionContinuousBase
{
	void ActionZenSearchProxy()
	{
		m_CallbackClass = ActionZenSearchProxyCB;
		m_CommandUID = DayZPlayerConstants.CMD_ACTIONFB_INTERACT;
		m_FullBody = true;
		m_StanceMask = DayZPlayerConstants.STANCEMASK_CROUCH | DayZPlayerConstants.STANCEMASK_ERECT;
		m_Text = "Search";
	}

	override void CreateConditionComponents()
	{
		m_ConditionItem = new CCINotPresent;
		m_ConditionTarget = new CCTCursor(UAMaxDistances.SMALL);
	}

	override bool HasZenProxyTarget()
	{
		return true;
	}

	override string GetZenProxyNameTarget()
	{
		return "lekarnicka,radio_b,fridge,library_a_open,library_a,sodamachine";
	}

	bool ZenFood_IsWinter(Object obj)
	{
		float temp = GetGame().GetMission().GetWorldData().GetBaseEnvTemperatureAtObject(obj);
		//ZenFunctions.DebugMessage("Temperature=" + temp);
		return temp < 0;
	}

	override bool ActionCondition(PlayerBase player, ActionTarget target, ItemBase item)
	{
		if (item != NULL || !IsTargetingZenActionProxy(player, target, item))
			return false;

		if (GetGame().IsClient())
		{
			// Cursor target object is not sync'd to server, so don't check server-side.
			vector proxyTargetLS;
			vector proxyTargetWS;
			string proxyTargetHouseType;
			string proxyTargetProxyType;

			proxyTargetProxyType = GetZenActionProxyTargetEx(player, target, item, proxyTargetLS, proxyTargetWS, proxyTargetHouseType);
		}

		return true;
	}

	override void OnFinishProgressServer(ActionData action_data)
	{
		string target = GetZenProxyTargetType(action_data);

		if (target == "lekarnicka")
			HandleSearchMedicineCabinet(action_data);
		else if (target == "radio_b")
			HandleSearchRadio(action_data);
		else if (target == "fridge")
			HandleSearchFridge(action_data);
		else if (target == "library_a_open" || target == "library_a")
			HandleSearchLibrary(action_data);
		else if (target == "sodamachine")
			HandleSearchSodaMachine(action_data);
	}

	//! SODA MACHINE
	void HandleSearchSodaMachine(ActionData action_data)
	{
		vector proxyTargetWS = GetZenProxyTargetWS(action_data);
		ZenProxySearchDummy item = ZenProxySearchDummy.Cast(GetProxyObject(proxyTargetWS, "ZenProxySearchDummy"));

		if (!item)
		{
			if (Math.RandomFloat01() < 0.1) // 10% chance of nothing
			{
				item = CreateProxyObject(proxyTargetWS);
			}
		}

		if (item)
		{
			NotifyPlayerNoLoot(action_data.m_Player);
			return;
		}

		CreateProxyObject(proxyTargetWS);

		string itemName = ZenProxyConfig.SODAS.GetRandomElement();
		ItemBase loot = ItemBase.Cast(action_data.m_Player.GetHumanInventory().CreateInHands(itemName));

		if (!loot)
		{
			Error("ActionZenSearchProxy: Failed to spawn item " + itemName + " - check classname");
			return;
		}

		if (ZenFood_IsWinter(action_data.m_Player))
		{
			loot.SetTemperatureDirect(-10);
			loot.SetFrozen(true);
		}

		loot.SetHealth(Math.RandomFloatInclusive(0.01, 0.5) * loot.GetMaxHealth("", ""));
	}

	//! LIBRARY
	void HandleSearchLibrary(ActionData action_data)
	{
		vector proxyTargetWS = GetZenProxyTargetWS(action_data);
		ZenProxySearchDummy item = ZenProxySearchDummy.Cast(GetProxyObject(proxyTargetWS, "ZenProxySearchDummy"));

		if (!item)
		{
			if (Math.RandomFloat01() < 0.5) // 50% chance of nothing
			{
				item = CreateProxyObject(proxyTargetWS);
			}
		}

		if (item)
		{
			NotifyPlayerNoLoot(action_data.m_Player);
			return;
		}

		CreateProxyObject(proxyTargetWS);

		string itemName = ZenProxyConfig.BOOKS.GetRandomElement();
		ItemBase loot = ItemBase.Cast(action_data.m_Player.GetHumanInventory().CreateInHands(itemName));

		if (!loot)
		{
			Error("ActionZenSearchProxy: Failed to spawn item " + itemName + " - check classname");
			return;
		}

		loot.SetHealth(Math.RandomFloatInclusive(0.01, 0.5) * loot.GetMaxHealth("", ""));
	}

	//! FRIDGE
	void HandleSearchFridge(ActionData action_data)
	{
		vector proxyTargetWS = GetZenProxyTargetWS(action_data);
		ZenProxySearchDummy item = ZenProxySearchDummy.Cast(GetProxyObject(proxyTargetWS, "ZenProxySearchDummy"));

		if (!item)
		{
			if (Math.RandomFloat01() < 0.5) // 50% chance of nothing
			{
				item = CreateProxyObject(proxyTargetWS);
			}
		}

		if (item)
		{
			NotifyPlayerNoLoot(action_data.m_Player);
			return;
		}

		CreateProxyObject(proxyTargetWS);

		string itemName = ZenProxyConfig.FOOD.GetRandomElement();
		ItemBase loot = ItemBase.Cast(action_data.m_Player.GetHumanInventory().CreateInHands(itemName));

		if (!loot)
		{
			Error("ActionZenSearchProxy: Failed to spawn item " + itemName + " - check classname");
			return;
		}

		if (ZenFood_IsWinter(action_data.m_Player))
		{
			loot.SetTemperatureDirect(-10);
			loot.SetFrozen(true);
		}

		loot.SetHealth(Math.RandomFloatInclusive(0.01, 0.5) * loot.GetMaxHealth("", ""));
	}

	//! RADIO
	void HandleSearchRadio(ActionData action_data)
	{
		vector proxyTargetWS = GetZenProxyTargetWS(action_data);
		ZenProxySearchDummy item = ZenProxySearchDummy.Cast(GetProxyObject(proxyTargetWS, "ZenProxySearchDummy"));

		if (!item)
		{
			if (Math.RandomFloat01() < 0.2) // 20% chance of nothing
			{
				item = CreateProxyObject(proxyTargetWS);
			}
		}

		if (item)
		{
			NotifyPlayerNoLoot(action_data.m_Player);
			return;
		}

		CreateProxyObject(proxyTargetWS);

		string itemName = ZenProxyConfig.CASSETTES.GetRandomElement();
		ItemBase loot = ItemBase.Cast(action_data.m_Player.GetHumanInventory().CreateInHands(itemName));
		if (!loot)
		{
			Error("ActionZenSearchProxy: Failed to spawn item " + itemName + " - check classname");
			return;
		}

		loot.SetHealth(Math.RandomFloatInclusive(0.1, 0.75) * loot.GetMaxHealth("", ""));
	}

	//! MEDICINE
	void HandleSearchMedicineCabinet(ActionData action_data)
	{
		vector proxyTargetWS = GetZenProxyTargetWS(action_data);
		ZenProxySearchDummy item = ZenProxySearchDummy.Cast(GetProxyObject(proxyTargetWS, "ZenProxySearchDummy"));

		if (!item)
		{
			if (Math.RandomFloat01() < 0.2) // 20% chance of nothing
			{
				item = CreateProxyObject(proxyTargetWS);
			}
		}

		if (item)
		{
			NotifyPlayerNoLoot(action_data.m_Player);
			return;
		}

		CreateProxyObject(proxyTargetWS);

		string itemName = ZenProxyConfig.MEDICINE.GetRandomElement();
		ItemBase loot = ItemBase.Cast(action_data.m_Player.GetHumanInventory().CreateInHands(itemName));
		if (!loot)
		{
			Error("ActionZenSearchProxy: Failed to spawn item " + itemName + " - check classname");
			return;
		}

		loot.SetQuantity(Math.RandomIntInclusive(1, 5));
		loot.SetHealth(Math.RandomFloatInclusive(0.01, 0.5) * loot.GetMaxHealth("", ""));
	}

	void NotifyPlayerNoLoot(PlayerBase player)
	{
		//NotificationSystem.SendNotificationToPlayerIdentityExtended(player.GetIdentity(), 5.0, "No luck.", "There's nothing interesting in there.", "set:ccgui_enforce image:xxx");
		//GetSyberiaRPC().SendToClient(SyberiaRPC.SYBRPC_SCREEN_MESSAGE, player.GetIdentity(), new Param1<string>("There's nothing interesting in there."));
		SendMessageToClient(player, "There's nothing interesting in there.");
	}

	protected ZenProxySearchDummy CreateProxyObject(vector pos)
	{
		// Create an invisible entity at this location - simplest way to sync the action to all players on the server and handle lifetime in XML etc.
		ZenProxySearchDummy proxyObj = ZenProxySearchDummy.Cast(GetGame().CreateObjectEx("ZenProxySearchDummy", pos, ECE_SETUP));
		return proxyObj;
	}

	// Continuous actions don't use this feature for some reason, so I hijack it in a janky way because I'm OCD
	// and I don't want the bush mining sound to play when players search stuff
	override string GetSoundCategory(ActionData action_data)
	{
		string target = GetZenProxyTargetType(action_data);

		if (target.Contains("library"))
			return "zenproxysearchpaper";

		if (target == "radio_b")
			return "zenproxysearchradio";

		return "zenproxysearch";
	}
}

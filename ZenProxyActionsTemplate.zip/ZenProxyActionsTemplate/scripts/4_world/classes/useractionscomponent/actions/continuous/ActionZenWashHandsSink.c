class ActionZenWashHandsSink : ActionWashHandsWell
{
	void ActionZenWashHandsSink()
	{
		m_CallbackClass = ActionWashHandsWellCB;
		m_CommandUID = DayZPlayerConstants.CMD_ACTIONFB_WASHHANDSWELL;
		m_FullBody = true;
		m_StanceMask = DayZPlayerConstants.STANCEMASK_CROUCH;
		m_Text = "#wash_hands";
	}

	override void CreateConditionComponents()
	{
		m_ConditionItem = new CCINone();
		m_ConditionTarget = new CCTCursor(UAMaxDistances.SMALL);
	}

	override bool HasZenProxyTarget()
	{
		return true;
	}

	override string GetZenProxyNameTarget()
	{
		return ZenProxyConstants.SINKS;
	}

	override bool ActionCondition(PlayerBase player, ActionTarget target, ItemBase item)
	{
		if (!IsTargetingZenActionProxy(player, target, item))
			return false;

		if (GetGame().IsClient())
		{
			// Cursor target object is not sync'd to server, so don't check server-side.
			vector proxyTargetLS;
			vector proxyTargetWS;
			string proxyTargetHouseType;
			string proxyTargetProxyType;

			proxyTargetProxyType = GetZenActionProxyTargetEx(player, target, item, proxyTargetLS, proxyTargetWS, proxyTargetHouseType);

			// If sink entity exists, then that means sink is already fixed
			Object sink = GetProxyObject(proxyTargetWS, "ZenProxySink");
			if (!sink)
				return false;
		}

		return player.HasBloodyHands() && !player.GetItemInHands() && !player.GetItemOnSlot("Gloves");
	}
}

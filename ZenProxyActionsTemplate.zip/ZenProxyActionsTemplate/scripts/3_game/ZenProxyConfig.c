class ZenProxyConfig
{
	static const ref array<string> MEDICINE =
	{
		"Bandage"
	};

	static const ref array<string> CASSETTES =
	{
		"Battery9V"
	};

	static const ref array<string> FOOD =
	{
		"HumanSteakMeat",
		"BakedBeansCan",
		"PeachesCan",
		"SpaghettiCan",
		"DogFoodCan",
		"CatFoodCan",
		"UnknownFoodCan",
		"SardinesCan",
		"TunaCan",
		"PorkCan",
		"Lunchmeat",
		"Pajka",
		"Pate",
		"BrisketSpread",
		"SodaCan_Pipsi",
		"SodaCan_Cola",
		"Magnum",
		"WaterBottle"
	};

	static const ref array<string> BOOKS =
	{
		"BookBible",
		"BookTheWarOfTheWorlds",
		"BookAroundTheWorldIn80Days",
		"BookCrimeAndPunishment",
		"BookTheRaven",
		"BookTheArtOfWar",
		"BookRussian",
		"BookTheTimeMachine",
		"BookYouth",
		"BookTheJungleBook",
		"BookTheBrothersKaramazov",
		"BookTheCallOfCthulhu",
		"BookTonyAndTheBeetles",
		"BookLonesomeLand",
		"BookTheThunderBird",
		"BookBlackJack",
		"BookTheLastTrail",
		"BookGunmansReckoning",
		"BookMobyDick",
		"BookPrideAndPrejudice",
		"BookNaturalSelection",
		"BookLordJim",
		"BookWealthOfNations",
		"BookThreeMenInABoat",
		"BookSkyrider",
		"BookTheDayOfTheBeast",
		"BookBlackBeauty",
		"BookDeadSouls",
		"BookGreatExpectations",
		"BookHeartOfDarkness",
		"BookKidnapped",
		"BookDracula",
		"BookRomeoUndJulia",
		"BookFrankenstein",
		"BookTheLastMan",
		"BookTreasureIsland",
		"BookWarAndPeace",
		"BookUlysses",
		"BookTheThreeMusketeers",
		"BookTheRightsOfWoman",
		"BookTheCallOfTheWild",
		"BookTheMonkARomance",
		"BookTheJustifiedSinner",
		"BookGilgameshEpic",
		"BookHunger",
		"BookAliceInWonderland",
		"BookTheCaveOfGold",
		"BookDesertGold",
		"BookRobinsonCrusoe"
	};

	static const ref array<string> SODAS =
	{
		"SodaCan_Pipsi",
		"SodaCan_Cola",
		"SodaCan_Spite",
		"SodaCan_Fronta",
		"SodaCan_Kvass"
	};
};
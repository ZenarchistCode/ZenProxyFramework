class CfgPatches
{
	class ZenProxyActionsTemplate
	{
		requiredVersion = 0.1;
		requiredAddons[] =
		{
			"DZ_Data",
			"DZ_Scripts",
			"ZenProxyFramework"
		};
	};
};

class CfgMods
{
	class ZenProxyActionsTemplate
	{
		dir = "ZenProxyActionsTemplate";
		picture = "";
		action = "";
		hideName = 1;
		hidePicture = 1;
		name = "ZenProxyActionsTemplate";
		credits = "";
		author = "Zenarchist";
		authorID = "0";
		version = "1.0";
		extra = 0;
		type = "mod";
		dependencies[] = { "Game","World","Mission" };
		class defs
		{
			class gameScriptModule
			{
				value = "";
				files[] = { "ZenProxyActionsTemplate/scripts/3_game" };
			};
			class worldScriptModule
			{
				value = "";
				files[] = { "ZenProxyActionsTemplate/scripts/4_world" };
			};
			class missionScriptModule
			{
				value = "";
				files[] = { "ZenProxyActionsTemplate/scripts/5_mission" };
			};
		};
	};
};

class CfgVehicles
{
	// Examples of spawnable proxy dummies for certain actions.
	// This allows you to add persistence to in-game actions.
	// For example, on my server when a player repairs a sink
	// I spawn a ZenProxySink object on it which my types.xml has a lifetime of 3 days
	// The sink itself is invisible to the player, but my action condition searches for the sink obj.
	// Same with SearchDummy - this object spawns when a player searches an in-game object like a fridge
	// to prevent repeating that action on that object for a few hours/days for all players on the server.
	class ZenProxyBase;
	class ZenProxySink : ZenProxyBase
	{
		scope = 2;
	};
	class ZenProxySearchDummy : ZenProxyBase
	{
		scope = 2;
	};
};
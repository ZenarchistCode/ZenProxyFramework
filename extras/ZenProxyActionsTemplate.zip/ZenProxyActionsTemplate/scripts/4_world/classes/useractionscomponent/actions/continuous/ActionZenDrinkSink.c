class ActionZenDrinkSink : ActionDrinkWellContinuous
{
	void ActionZenDrinkSink()
	{
		m_CallbackClass = ActionDrinkWellContinuousCB;
		m_CommandUID = DayZPlayerConstants.CMD_ACTIONFB_DRINKWELL;
		m_FullBody = true;
		m_StanceMask = DayZPlayerConstants.STANCEMASK_CROUCH | DayZPlayerConstants.STANCEMASK_ERECT;
		m_Text = "#drink";
	}

	override void CreateConditionComponents()
	{
		m_ConditionItem = new CCINone();
		m_ConditionTarget = new CCTCursor(UAMaxDistances.SMALL);
	}

	override bool HasZenProxyTarget()
	{
		return true;
	}

	override string GetZenProxyNameTarget()
	{
		return ZenProxyConstants.SINKS;
	}

	override bool IsDrink()
	{
		return true;
	}

	override bool ActionCondition(PlayerBase player, ActionTarget target, ItemBase item)
	{
		if (!IsTargetingZenActionProxy(player, target, item))
			return false;

		if (item && item.IsHeavyBehaviour())
			return false;

		if (!player.CanEatAndDrink())
			return false;

		if (g_Game.IsClient())
		{
			// Cursor target object is not sync'd to server, so don't check server-side.
			vector proxyTargetLS;
			vector proxyTargetWS;
			string proxyTargetHouseType;
			string proxyTargetProxyType;

			proxyTargetProxyType = GetZenActionProxyTargetEx(player, target, item, proxyTargetLS, proxyTargetWS, proxyTargetHouseType);

			// If sink entity exists, then that means sink is already fixed
			Object sink = GetProxyObject(proxyTargetWS, "ZenProxySink");
			if (!sink)
				return false;
		}

		return true;
	}

	override protected bool CanContinue(ActionData action_data)
	{
		if (!action_data || !action_data.m_Player)
		{
			return false;
		}

		if (!action_data.m_Player.IsPlayerInStance(action_data.m_PossibleStanceMask))
		{
			return false;
		}

		if (!m_ConditionItem || !m_ConditionItem.CanContinue(action_data.m_Player, action_data.m_MainItem))
		{
			return false;
		}

		string proxyType = GetZenProxyTargetType(action_data);
		vector proxyWS = GetZenProxyTargetWS(action_data);

		if (proxyType == "" || proxyWS == vector.Zero)
		{
			return false;
		}

		if (action_data.m_MainItem && action_data.m_MainItem.IsHeavyBehaviour())
		{
			return false;
		}

		if (!action_data.m_Player.CanEatAndDrink())
		{
			return false;
		}

		// Validate distance against the ACTUAL Zen proxy position,
		// not DayZ 1.29's replacement building ActionTarget.
		vector playerHeadPos;
		MiscGameplayFunctions.GetHeadBonePos(action_data.m_Player, playerHeadPos);

		float maxDistanceSq = UAMaxDistances.DEFAULT * UAMaxDistances.DEFAULT;
		float distanceRoot = vector.DistanceSq(proxyWS, action_data.m_Player.GetPosition());
		float distanceHead = vector.DistanceSq(proxyWS, playerHeadPos);

		if (distanceRoot > maxDistanceSq && distanceHead > maxDistanceSq)
		{
			return false;
		}

		return true;
	}

	override void OnFinishProgressServer(ActionData action_data)
	{
		Param1<float> nacdata = Param1<float>.Cast(action_data.m_ActionComponent.GetACData());
		if (nacdata)
		{
			float amount = UAQuantityConsumed.DRINK;
			action_data.m_Player.Consume(null, amount, EConsumeType.ENVIRO_POND);
		}

		if (action_data.m_Player.HasBloodyHands() && !action_data.m_Player.GetInventory().FindAttachment(InventorySlots.GLOVES))
		{
			action_data.m_Player.SetBloodyHandsPenalty();
		}
	}
}

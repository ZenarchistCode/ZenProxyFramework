class ActionZenSleepBed : ActionInteractBase
{
    void ActionZenSleepBed()
    {
        m_CallbackClass = ActionZenProxyInteractCB;
        m_CommandUID = DayZPlayerConstants.CMD_ACTIONMOD_INTERACTONCE;
        m_StanceMask = DayZPlayerConstants.STANCEMASK_ALL;
    }

    override void CreateConditionComponents()
    {
        m_ConditionItem = new CCINotPresent;
        m_ConditionTarget = new CCTCursor(UAMaxDistances.DEFAULT);
    }

    override string GetText()
    {
        return "#STR_USRACT_ID_EMOTE_LYINGDOWN";
    }

    override bool HasZenProxyTarget()
    {
        return true;
    }

    override bool IsInstant()
	{
		return true;
	}

    override string GetZenProxyNameTarget()
    {
        return ZenProxyConstants.BEDS;
    }

    override bool ActionCondition(PlayerBase player, ActionTarget target, ItemBase item)
    {
        return IsTargetingZenActionProxy(player, target, item);
    }

    override void Start(ActionData action_data)
	{
		super.Start(action_data);

        if (action_data.m_Player.GetEmoteManager())
        {
            action_data.m_Player.GetEmoteManager().CreateEmoteCBFromMenu(EmoteConstants.ID_EMOTE_LYINGDOWN);
            action_data.m_Player.SetZenSleepingInBed(true);
        }
    }
}
